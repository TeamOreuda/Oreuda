-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `readme_techstack`
--

DROP TABLE IF EXISTS `readme_techstack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `readme_techstack` (
  `readme_techstack_id` bigint NOT NULL AUTO_INCREMENT,
  `readme_order` int NOT NULL,
  `readme_techstack_title` varchar(255) DEFAULT NULL,
  `readme_id` bigint NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`readme_techstack_id`),
  KEY `FKk7qq0yk3qalf5afd6kyqe10c0` (`readme_id`),
  KEY `FKa3u2v0e0ctjt5x1g9uvrrwu17` (`user_id`),
  CONSTRAINT `FKa3u2v0e0ctjt5x1g9uvrrwu17` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKk7qq0yk3qalf5afd6kyqe10c0` FOREIGN KEY (`readme_id`) REFERENCES `readme` (`readme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `readme_techstack`
--

LOCK TABLES `readme_techstack` WRITE;
/*!40000 ALTER TABLE `readme_techstack` DISABLE KEYS */;
INSERT INTO `readme_techstack` VALUES (35,3,'',14,'832b83c9-8db8-4210-8326-230761789d06'),(36,5,'백엔드',15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(37,6,'프론트엔드',15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(40,1,'c / c++ 개발자입니다.',13,'8c626e3a-7812-4117-be15-9e9ed83e8810'),(43,1,'',20,'7881c652-8597-4dda-bd19-27b632e920d6'),(44,2,'백엔드',12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(45,3,'프론트 엔드',12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(49,3,'프론트엔드',23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(50,4,'백엔드',23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(51,1,'java',26,'9138effc-3cdd-44d5-9cb2-86068bffb07e'),(54,2,'Language',31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(55,3,'Framework',31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(56,4,'Database',31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(57,3,'오오',32,'a18e0847-39e3-4b0a-b55a-73bd75c95383'),(58,4,'Backend',33,'e6fbc65d-d333-4539-8bef-470293ac5fc6'),(59,4,'',35,'45fefc71-8e8d-4334-b711-57c9de487392'),(60,3,'',36,'ed908306-9a1f-416a-b2a6-e90a0999e8a5'),(71,1,'FrontEnd',42,'96826af7-2a23-40fe-8dd9-82b2495eb168'),(72,2,'BackEnd',42,'96826af7-2a23-40fe-8dd9-82b2495eb168'),(73,3,'Data',42,'96826af7-2a23-40fe-8dd9-82b2495eb168'),(79,3,'Language',11,'7b505495-9843-4b01-afff-63f3e8973802'),(80,2,'Reverse Engineering',44,'0576eb43-560a-475c-9341-2e0ca0278444'),(81,3,'Digital Forensic',44,'0576eb43-560a-475c-9341-2e0ca0278444'),(82,4,'Security Engineering',44,'0576eb43-560a-475c-9341-2e0ca0278444'),(83,5,'Incident Response',44,'0576eb43-560a-475c-9341-2e0ca0278444');
/*!40000 ALTER TABLE `readme_techstack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:22
