-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gitstats`
--

DROP TABLE IF EXISTS `gitstats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gitstats` (
  `gitstats_id` bigint NOT NULL AUTO_INCREMENT,
  `readme_order` int NOT NULL,
  `gitstats_theme` varchar(255) NOT NULL,
  `readme_id` bigint NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`gitstats_id`),
  KEY `FKqvxwxkcosojc4ow10mlct1uqe` (`readme_id`),
  KEY `FKbiyt7nqhsinqtirp3fcfn4y9k` (`user_id`),
  CONSTRAINT `FKbiyt7nqhsinqtirp3fcfn4y9k` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKqvxwxkcosojc4ow10mlct1uqe` FOREIGN KEY (`readme_id`) REFERENCES `readme` (`readme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gitstats`
--

LOCK TABLES `gitstats` WRITE;
/*!40000 ALTER TABLE `gitstats` DISABLE KEYS */;
INSERT INTO `gitstats` VALUES (14,2,'gruvbox',14,'832b83c9-8db8-4210-8326-230761789d06'),(15,4,'radical',15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(20,1,'gruvbox',19,'83ae33ca-6399-4651-8295-d2f43efc718b'),(21,3,'tokyonight',20,'7881c652-8597-4dda-bd19-27b632e920d6'),(22,5,'dark',12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(25,1,'dark',23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(26,1,'dark',25,'a9c827f9-9b18-4d25-9ede-277dc8ddbc96'),(27,1,'dark',27,'eb2d5485-edfc-40b5-8f64-52e01c2824c0'),(28,1,'cobalt',29,'22965914-9a3c-448c-b120-b697ee980f1f'),(30,0,'radical',30,'fa19b312-c6ab-4dd8-99f6-132e23f1f168'),(33,5,'dark',31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(34,0,'gruvbox',32,'a18e0847-39e3-4b0a-b55a-73bd75c95383'),(35,1,'onedark',33,'e6fbc65d-d333-4539-8bef-470293ac5fc6'),(36,0,'dark',34,'0bd7c2d2-c8bd-43f7-bbb8-d05dd1c7626e'),(37,2,'dark',35,'45fefc71-8e8d-4334-b711-57c9de487392'),(38,1,'tokyonight',36,'ed908306-9a1f-416a-b2a6-e90a0999e8a5'),(39,2,'tokyonight',38,'407226f7-c717-44bd-9814-5e7de6bc4700'),(40,1,'tokyonight',40,'7fac0610-7e78-4832-82c3-f4806c3e8dba'),(50,2,'tokyonight',41,'7b2be57e-b197-4044-9126-60b75f5eed45'),(52,4,'tokyonight',42,'96826af7-2a23-40fe-8dd9-82b2495eb168'),(58,1,'radical',11,'7b505495-9843-4b01-afff-63f3e8973802'),(59,2,'cobalt',45,'5d58731b-9e4f-4021-9bb8-760c82f9b3e1');
/*!40000 ALTER TABLE `gitstats` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:22
