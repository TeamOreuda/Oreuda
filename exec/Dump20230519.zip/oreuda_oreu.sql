-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oreu`
--

DROP TABLE IF EXISTS `oreu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oreu` (
  `oreu_id` bigint NOT NULL AUTO_INCREMENT,
  `readme_order` int NOT NULL,
  `readme_id` bigint NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`oreu_id`),
  KEY `FKtjknapuwo54abgut68t8khxv1` (`readme_id`),
  KEY `FKhdvcj4ye227d49gr6vljtn2lf` (`user_id`),
  CONSTRAINT `FKhdvcj4ye227d49gr6vljtn2lf` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKtjknapuwo54abgut68t8khxv1` FOREIGN KEY (`readme_id`) REFERENCES `readme` (`readme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oreu`
--

LOCK TABLES `oreu` WRITE;
/*!40000 ALTER TABLE `oreu` DISABLE KEYS */;
INSERT INTO `oreu` VALUES (12,5,14,'832b83c9-8db8-4210-8326-230761789d06'),(15,1,15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(16,2,16,'e9a9108d-99b1-4e64-995b-77cfad430656'),(18,0,18,'abc04173-b811-4058-9d29-a44e88c177f6'),(22,4,19,'83ae33ca-6399-4651-8295-d2f43efc718b'),(23,0,20,'7881c652-8597-4dda-bd19-27b632e920d6'),(25,1,12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(28,6,23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(29,4,25,'a9c827f9-9b18-4d25-9ede-277dc8ddbc96'),(30,0,26,'9138effc-3cdd-44d5-9cb2-86068bffb07e'),(31,4,27,'eb2d5485-edfc-40b5-8f64-52e01c2824c0'),(32,4,29,'22965914-9a3c-448c-b120-b697ee980f1f'),(34,3,30,'fa19b312-c6ab-4dd8-99f6-132e23f1f168'),(37,6,31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(38,2,32,'a18e0847-39e3-4b0a-b55a-73bd75c95383'),(39,0,33,'e6fbc65d-d333-4539-8bef-470293ac5fc6'),(40,4,34,'0bd7c2d2-c8bd-43f7-bbb8-d05dd1c7626e'),(41,0,35,'45fefc71-8e8d-4334-b711-57c9de487392'),(42,5,36,'ed908306-9a1f-416a-b2a6-e90a0999e8a5'),(43,0,38,'407226f7-c717-44bd-9814-5e7de6bc4700'),(44,0,39,'3bc445d1-32f6-4eba-979f-cbf2ce8e3802'),(45,4,40,'7fac0610-7e78-4832-82c3-f4806c3e8dba'),(55,1,41,'7b2be57e-b197-4044-9126-60b75f5eed45'),(58,2,43,'edf9f7af-801d-4ab4-a832-3e9aeb9382ec'),(63,0,11,'7b505495-9843-4b01-afff-63f3e8973802'),(64,7,44,'0576eb43-560a-475c-9341-2e0ca0278444'),(65,0,45,'5d58731b-9e4f-4021-9bb8-760c82f9b3e1');
/*!40000 ALTER TABLE `oreu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:25
