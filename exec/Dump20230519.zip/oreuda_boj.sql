-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boj`
--

DROP TABLE IF EXISTS `boj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boj` (
  `boj_id` bigint NOT NULL AUTO_INCREMENT,
  `readme_order` int NOT NULL,
  `boj_theme` varchar(255) NOT NULL,
  `boj_value` varchar(36) NOT NULL,
  `readme_id` bigint NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`boj_id`),
  KEY `FKaknfy4ntswvlyjqt0eap99y9d` (`readme_id`),
  KEY `FK2n6nfl731h66mc4uljinrb42w` (`user_id`),
  CONSTRAINT `FK2n6nfl731h66mc4uljinrb42w` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKaknfy4ntswvlyjqt0eap99y9d` FOREIGN KEY (`readme_id`) REFERENCES `readme` (`readme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boj`
--

LOCK TABLES `boj` WRITE;
/*!40000 ALTER TABLE `boj` DISABLE KEYS */;
INSERT INTO `boj` VALUES (24,0,'warm','oth5447',14,'832b83c9-8db8-4210-8326-230761789d06'),(26,3,'dark','sjj02055',15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(27,0,'cold','now2466',16,'e9a9108d-99b1-4e64-995b-77cfad430656'),(29,0,'cold','wlswl2435',17,'a16efa91-8517-4f41-b0f7-b10e93cf5c41'),(32,0,'cold','misso88',19,'83ae33ca-6399-4651-8295-d2f43efc718b'),(33,2,'warm','fixup719',20,'7881c652-8597-4dda-bd19-27b632e920d6'),(34,0,'cold','yjin99',21,'b1c4f35c-5922-45d6-854e-e4e95328fe38'),(36,0,'warm','wjdwn03',22,'ad3570c4-5513-415e-adb3-b9c724f07081'),(37,6,'warm','jiyeon416',12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(40,0,'dark','kyum8562',23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(41,0,'cold','mgin0527',24,'3c88bd8a-0827-4861-b8b3-af7231eb962d'),(42,0,'dark','sogur928',25,'a9c827f9-9b18-4d25-9ede-277dc8ddbc96'),(43,0,'warm','temp',27,'eb2d5485-edfc-40b5-8f64-52e01c2824c0'),(44,0,'warm','skqltldnjf',28,'7f85baff-df10-4ac5-b8fb-1fb725953ad8'),(45,0,'warm','et2468',29,'22965914-9a3c-448c-b120-b697ee980f1f'),(49,0,'warm','ssafydaily',31,'e0e12a41-75ee-47ed-851a-d739dac31d87'),(51,5,'dark','dl_skflsalfm@naver.com',32,'a18e0847-39e3-4b0a-b55a-73bd75c95383'),(52,2,'dark','dltkdgkr123',33,'e6fbc65d-d333-4539-8bef-470293ac5fc6'),(53,2,'cold','cwelly',34,'0bd7c2d2-c8bd-43f7-bbb8-d05dd1c7626e'),(54,1,'dark','bundo10',35,'45fefc71-8e8d-4334-b711-57c9de487392'),(55,0,'warm','gksdidtk123',36,'ed908306-9a1f-416a-b2a6-e90a0999e8a5'),(56,0,'warm','ssleekr',37,'562c06d3-3d04-4398-9bec-c04cfa007db3'),(57,0,'warm','temp',40,'7fac0610-7e78-4832-82c3-f4806c3e8dba'),(61,0,'warm','sju3358',41,'7b2be57e-b197-4044-9126-60b75f5eed45'),(62,6,'warm','hongym0497',42,'96826af7-2a23-40fe-8dd9-82b2495eb168'),(63,0,'warm','temp',43,'edf9f7af-801d-4ab4-a832-3e9aeb9382ec'),(66,0,'warm','lih0318',44,'0576eb43-560a-475c-9341-2e0ca0278444');
/*!40000 ALTER TABLE `boj` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:24
