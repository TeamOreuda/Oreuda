-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `writing`
--

DROP TABLE IF EXISTS `writing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `writing` (
  `writing_id` bigint NOT NULL AUTO_INCREMENT,
  `writing_contents` text,
  `readme_order` int NOT NULL,
  `writing_title` varchar(255) DEFAULT NULL,
  `readme_id` bigint NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`writing_id`),
  KEY `FKl6jbvqoskr3umbk3fuhmhm6p1` (`readme_id`),
  KEY `FK8mrfniph4tpttk809hpkiumm` (`user_id`),
  CONSTRAINT `FK8mrfniph4tpttk809hpkiumm` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKl6jbvqoskr3umbk3fuhmhm6p1` FOREIGN KEY (`readme_id`) REFERENCES `readme` (`readme_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `writing`
--

LOCK TABLES `writing` WRITE;
/*!40000 ALTER TABLE `writing` DISABLE KEYS */;
INSERT INTO `writing` VALUES (27,'하이',6,'안녕하세요',14,'832b83c9-8db8-4210-8326-230761789d06'),(31,'tgtgyhyh8',0,'gbgybgyb',15,'59e7405b-e79c-4050-9dbb-0f963e142a25'),(35,'개발자입니다.',5,'안녕하세요',19,'83ae33ca-6399-4651-8295-d2f43efc718b'),(37,'안녕하세요. 다양한 경험을 즐기는 개발자입니다. ❤',0,'자기소개',12,'6fcebc5d-9731-4714-8402-1c6df687b2d2'),(44,'내용1',7,'텍스트1',23,'182a9b51-4ceb-46a4-a21e-a9225b47bed4'),(45,'잘만들었어요',6,'서비스 신기하네요',35,'45fefc71-8e8d-4334-b711-57c9de487392'),(46,'GD',5,'GD',40,'7fac0610-7e78-4832-82c3-f4806c3e8dba'),(61,'개발을 재밌어하는 프론트엔드 개발자입니다',4,'안녕하세요.',11,'7b505495-9843-4b01-afff-63f3e8973802'),(62,'고려대학교 정보보호대학원 DFRC 연구실 45기 석사 과정 재학중',8,'DFRC 연구원',44,'0576eb43-560a-475c-9341-2e0ca0278444');
/*!40000 ALTER TABLE `writing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:27
