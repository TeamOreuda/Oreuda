-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.79.221.133    Database: oreuda
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `techstack`
--

DROP TABLE IF EXISTS `techstack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `techstack` (
  `techstack_id` bigint NOT NULL AUTO_INCREMENT,
  `techstack_name` varchar(255) NOT NULL,
  `techstack_index` int NOT NULL,
  `techstack_color` varchar(255) NOT NULL,
  `techstack_order` int NOT NULL,
  `readme_techstack_id` bigint NOT NULL,
  PRIMARY KEY (`techstack_id`),
  KEY `FKmy3mrb4hy5a0nbm8ubo3k9wab` (`readme_techstack_id`),
  CONSTRAINT `FKmy3mrb4hy5a0nbm8ubo3k9wab` FOREIGN KEY (`readme_techstack_id`) REFERENCES `readme_techstack` (`readme_techstack_id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techstack`
--

LOCK TABLES `techstack` WRITE;
/*!40000 ALTER TABLE `techstack` DISABLE KEYS */;
INSERT INTO `techstack` VALUES (51,'javascript',1,'f1e05a',0,35),(52,'typescript',2,'31859c',1,35),(53,'java',9,'b07219',2,35),(54,'html5',15,'e44b23',3,35),(55,'css',18,'563d7c',4,35),(56,'python',21,'3581ba',5,35),(57,'swift',12,'ffac45',0,36),(58,'css',18,'563d7c',1,36),(59,'html5',15,'e44b23',2,36),(60,'cpp',14,'f34b7d',0,37),(61,'html5',15,'e44b23',1,37),(62,'assembly',17,'6e4c13',2,37),(63,'perl',11,'0298c3',3,37),(64,'r',20,'198ce7',4,37),(69,'c',13,'555',0,40),(70,'cpp',14,'f34b7d',1,40),(71,'objective-c',4,'438eff',2,40),(76,'java',9,'b07219',0,43),(77,'html5',15,'e44b23',1,43),(78,'css',18,'563d7c',2,43),(79,'typescript',2,'31859c',3,43),(80,'javascript',1,'f1e05a',4,43),(81,'java',9,'b07219',0,44),(82,'c',13,'555',1,44),(83,'cpp',14,'f34b7d',2,44),(84,'javascript',1,'f1e05a',0,45),(85,'typescript',2,'31859c',1,45),(86,'html5',15,'e44b23',2,45),(87,'css',18,'563d7c',3,45),(100,'javascript',1,'f1e05a',0,49),(101,'typescript',2,'31859c',1,49),(102,'jirasoftware',57,'0052CC',2,49),(103,'nginx',56,'009639',3,49),(104,'git',55,'F05032',4,49),(105,'other',23,'b8b7b7',0,50),(106,'node.js',24,'339933',1,50),(107,'swift',12,'ffac45',2,50),(108,'shell',5,'89e051',3,50),(109,'springboot',34,'6DB33F',0,51),(114,'javascript',1,'f1e05a',0,54),(115,'java',9,'b07219',1,54),(116,'c',13,'555',2,54),(117,'html5',15,'e44b23',3,54),(118,'cpp',14,'f34b7d',4,54),(119,'css',18,'563d7c',5,54),(120,'python',21,'3581ba',6,54),(121,'vue.js',29,'4FC08D',0,55),(122,'django',30,'092E20',1,55),(123,'spring',33,'6DB33F',2,55),(124,'oracle',44,'F80000',0,56),(125,'mariadb',39,'003545',1,56),(126,'sqlite',38,'003B57',2,56),(127,'mysql',37,'4479A1',3,56),(128,'javascript',1,'f1e05a',0,57),(129,'python',21,'3581ba',1,57),(130,'node.js',24,'339933',2,57),(131,'mysql',37,'4479A1',0,58),(132,'nginx',56,'009639',1,58),(133,'git',55,'F05032',2,58),(134,'jenkins',47,'D24939',3,58),(135,'java',9,'b07219',0,59),(136,'python',21,'3581ba',1,59),(137,'java',9,'b07219',0,60),(138,'springboot',34,'6DB33F',1,60),(139,'mysql',37,'4479A1',2,60),(140,'redis',41,'DC382D',3,60),(141,'git',55,'F05032',4,60),(172,'javascript',1,'f1e05a',0,71),(173,'css',18,'563d7c',1,71),(174,'react',25,'61DAFB',2,71),(175,'node.js',24,'339933',3,71),(176,'vue.js',29,'4FC08D',4,71),(177,'flask',31,'000000',0,72),(178,'django',30,'092E20',1,72),(179,'spring',33,'6DB33F',2,72),(180,'python',21,'3581ba',3,72),(181,'java',9,'b07219',4,72),(182,'jupyter-notebook',22,'36a2eb',0,73),(183,'python',21,'3581ba',1,73),(184,'mysql',37,'4479A1',2,73),(185,'docker',48,'2496ED',3,73),(186,'git',55,'F05032',4,73),(199,'typescript',2,'31859c',0,79),(200,'vue.js',29,'4FC08D',1,79),(201,'c',13,'555',0,80),(202,'python',21,'3581ba',1,80);
/*!40000 ALTER TABLE `techstack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19  9:06:24
